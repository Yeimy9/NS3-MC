/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 */




/*
 * Description:
 * this file models the simple example of MOLECULAR-based communication.
 * xxx: add more comments (i.e., description of the scenario)
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/p1906-helper.h"
#include "ns3/p1906-net-device.h"
#include "ns3/p1906-mol-perturbation.h"
#include "ns3/p1906-mol-field.h"
#include "ns3/p1906-mol-motion.h"
#include "ns3/p1906-mol-specificity.h"
#include "ns3/p1906-medium.h"
#include "ns3/p1906-mol-communication-interface.h"
#include "ns3/p1906-mol-transmitter-communication-interface.h"
#include "ns3/p1906-mol-receiver-communication-interface.h"
#include <cstdlib>
#include <bitset>
#include <ctime>
#include <string>
#include <unordered_set>
#include <map>

using namespace ns3;

// Función que genera una lista de n aminoácidos aleatorios sin repeticiones
std::vector<std::string> generarAminoacidos(int n) {
    // Lista de los 20 aminoácidos
    std::vector<std::string> aminoacidos = {
        "Alanina", "Arginina", "Asparagina", "Ácido aspártico", "Cisteína",
        "Ácido glutámico", "Glutamina", "Glicina", "Histidina", "Isoleucina",
        "Leucina", "Lisina", "Metionina", "Fenilalanina", "Prolina",
        "Serina", "Treonina", "Triptófano", "Tirosina", "Valina"
    };

    // Verificar si n es mayor que la cantidad total de aminoácidos
    if (n >  static_cast<int>(aminoacidos.size())) {
        std::cerr << "Error: No hay suficientes aminoácidos para generar la cantidad especificada.\n";
        exit(EXIT_FAILURE);
    }

    // Obtener n índices aleatorios sin repeticiones
    srand(static_cast<unsigned int>(time(0)));
    std::vector<int> indicesAleatorios;

    for (int i = 0; i < n; ++i) {
        int indiceAleatorio;
        do {
            indiceAleatorio = rand() % aminoacidos.size();
        } while (std::find(indicesAleatorios.begin(), indicesAleatorios.end(), indiceAleatorio) != indicesAleatorios.end());

        indicesAleatorios.push_back(indiceAleatorio);
    }

    // Construir la lista de aminoácidos aleatorios
    std::vector<std::string> aminoacidosAleatorios;

    for (int indice : indicesAleatorios) {
        aminoacidosAleatorios.push_back(aminoacidos[indice]);
    }

    return aminoacidosAleatorios;
}

// Función que obtiene una combinación de codones aleatoria para un aminoácido
std::string obtenerCombinacionCodonesAleatoria(const std::string& aminoacido) {
    // Tabla de correspondencia entre aminoácidos y todas las combinaciones de codones
    std::map<std::string, std::vector<std::string>> tablaCodones = {
        {"Alanina", {"GCA", "GCC", "GCG", "GCU"}},
        {"Arginina", {"AGA", "AGG", "CGA", "CGC", "CGG", "CGU"}},
        {"Asparagina", {"AAC", "AAU"}},
        {"Ácido aspártico", {"GAC", "GAU"}},
        {"Cisteína", {"UGC", "UGU"}},
        {"Ácido glutámico", {"GAA", "GAG"}},
        {"Glutamina", {"CAA", "CAG"}},
        {"Glicina", {"GGA", "GGC", "GGG", "GGU"}},
        {"Histidina", {"CAC", "CAU"}},
        {"Isoleucina", {"AUA", "AUC", "AUU"}},
        {"Leucina", {"CUA", "CUC", "CUG", "CUU", "UUA", "UUG"}},
        {"Lisina", {"AAA", "AAG"}},
        {"Metionina", {"AUG"}},
        {"Fenilalanina", {"UUC", "UUU"}},
        {"Prolina", {"CCA", "CCC", "CCG", "CCU"}},
        {"Serina", {"AGC", "AGU", "UCA", "UCC", "UCG", "UCU"}},
        {"Treonina", {"ACA", "ACC", "ACG", "ACU"}},
        {"Triptófano", {"UGG"}},
        {"Tirosina", {"UAC", "UAU"}},
        {"Valina", {"GUA", "GUC", "GUG", "GUU"}}
    };

    // Buscar el aminoácido en la tabla y obtener sus combinaciones de codones
    auto it = tablaCodones.find(aminoacido);
    if (it != tablaCodones.end()) {
        // Obtener una combinación de codones aleatoria
        const std::vector<std::string>& combinacionesCodones = it->second;
        int indiceAleatorio = rand() % combinacionesCodones.size();
        return combinacionesCodones[indiceAleatorio];
    } else {
        std::cerr << "Error: Aminoácido no encontrado en la tabla de codones.\n";
        exit(EXIT_FAILURE);
    }
}
std::string convertirCodonABinario(const std::string& codon) {
    std::string resultado = "";

    for (char nucleotido : codon) {
        switch (nucleotido) {
            case 'U':
                resultado += "00";
                break;
            case 'C':
                resultado += "01";
                break;
            case 'A':
                resultado += "10";
                break;
            case 'G':
                resultado += "11";
                break;
            default:
                resultado += "NN";
                break;
        }
    }

    return resultado;
}

int main (int argc, char *argv[])
{	

  //set of parameters
  double nodeDistance =  2.1 * pow(10,-6);				   //  [m] 
  double nbOfMoleculas = 5000; 					      //  [pJ]
  double pulseInterval = 7000;					      //  [ms]
  double diffusionCoefficient = 1000;			    //  [nm^2/s]
  double timeSlot = 260;						    // Number of time slots divided by simulation time (ts)
  double receptionRadio = 8* pow(10,-6);	         // Reception Radio
  							  

  double driftVelocity =1 * pow(10,-6);					// [m/s]
  double driftAngule = M_PI*0; 								     // [rad]


  CommandLine cmd;
  cmd.AddValue("nodeDistance", "nodeDistance", nodeDistance);
  cmd.AddValue("nbOfMoleculas", "nbOfMoleculas", nbOfMoleculas);
  cmd.AddValue("diffusionCoefficient", "diffusionCoefficient", diffusionCoefficient);
  cmd.AddValue("pulseInterval", "pulseInterval", pulseInterval);


  cmd.AddValue("timeSlot", "timeSlot", timeSlot);
  cmd.AddValue("receptionRadio", "receptionRadio", receptionRadio);

  
  
  
  cmd.Parse(argc, argv);

  diffusionCoefficient = diffusionCoefficient * 1e-9;

  Time::SetResolution(Time::NS);

  // Create P1906 Helper
  P1906Helper helper;
  helper.EnableLogComponents ();

  // Create nodes (typical operation of ns-3)
  NodeContainer n;
  NetDeviceContainer d;
  n.Create (2);

  // Create a medium and the Motion component
  Ptr<P1906Medium> medium = CreateObject<P1906Medium> ();
  Ptr<P1906MOLMotion> motion = CreateObject<P1906MOLMotion> ();
  motion->SetDiffusionCoefficient (diffusionCoefficient);
  medium->SetP1906Motion (motion);
  medium->SetSlot(timeSlot);
  medium->SetRadio(receptionRadio);
  medium->SetMolecules(nbOfMoleculas);
  medium->Setpos(nodeDistance);

  // Create Device 1 and related components/entities
  Ptr<P1906NetDevice> dev1 = CreateObject<P1906NetDevice> ();
  Ptr<P1906MOLCommunicationInterface> c1 = CreateObject<P1906MOLCommunicationInterface> ();
  Ptr<P1906MOLSpecificity> s1 = CreateObject<P1906MOLSpecificity> ();
  Ptr<P1906MOLField> fi1 = CreateObject<P1906MOLField> ();
  Ptr<P1906MOLPerturbation> p1 = CreateObject<P1906MOLPerturbation> ();
  p1->SetPulseInterval (MilliSeconds(pulseInterval));
  p1->SetMolecules (nbOfMoleculas);
  s1->SetDiffusionCoefficient (diffusionCoefficient);
  fi1->SetVelocityDrift(driftVelocity);
  fi1->SetAngleDrift(driftAngule);
  

  // Create Device 2 and related components/entities
  Ptr<P1906NetDevice> dev2 = CreateObject<P1906NetDevice> ();
  Ptr<P1906MOLCommunicationInterface> c2 = CreateObject<P1906MOLCommunicationInterface> ();
  Ptr<P1906MOLSpecificity> s2 = CreateObject<P1906MOLSpecificity> ();
  Ptr<P1906MOLField> fi2 = CreateObject<P1906MOLField> ();
  Ptr<P1906MOLPerturbation> p2 = CreateObject<P1906MOLPerturbation> ();
  p2->SetPulseInterval (MilliSeconds(pulseInterval));
  p2->SetMolecules (nbOfMoleculas);
  s2->SetDiffusionCoefficient (diffusionCoefficient);
  fi2->SetVelocityDrift(driftVelocity);
  fi2->SetAngleDrift(driftAngule);

  //set devices positions
  Ptr<ListPositionAllocator> positionAlloc =
		  CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector(0, 0, 0));
  positionAlloc->Add (Vector(nodeDistance, 0, 0));
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.SetPositionAllocator(positionAlloc);
  mobility.Install(n);


  // Connect devices, nodes, medium, components and entities
  d.Add (dev1);
  d.Add (dev2);
  helper.Connect(n.Get (0),dev1,medium,c1,fi1, p1,s1);
  helper.Connect(n.Get (1),dev2,medium,c2,fi2, p2,s2);

  // Create a message to sent into the network
  int pktSize = 1; //bytes
  uint8_t *buffer  = new uint8_t[pktSize];

    // Llamar a la función para obtener una lista de aminoácidos aleatorios sin repeticiones
    std::vector<std::string> aminoacidos = generarAminoacidos(pktSize);
    std::vector<std::string> codones;

    // Mostrar el resultado y sus respectivas combinaciones de codones aleatorias
    //std::cout << "Aminoácidos generados con sus combinaciones de codones aleatorias:" << std::endl;

    for (const std::string& aminoacido : aminoacidos) {
        std::string combinacionCodones = obtenerCombinacionCodonesAleatoria(aminoacido);
        codones.push_back(combinacionCodones);
        std::cout << "- " << aminoacido << ": "<< combinacionCodones << std::endl;
    }
    for(int i=0;i< static_cast<int>(codones.size());i++){
        buffer[i]=static_cast<uint8_t>(std::stoi(convertirCodonABinario(codones[i]),nullptr,2));
        std::cout << " Packet: "<< convertirCodonABinario(codones[i])<<std::endl;
        //" Decimal " << static_cast<int>(buffer[i]) <<std::endl;
    }


 
  Ptr<Packet> message = Create<Packet>(buffer, pktSize);

  c1->HandleTransmission (message);
  Simulator::Run ();

  Simulator::Destroy ();
  return 0;
}
