/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 */



#include "ns3/log.h"
#include "ns3/packet.h"
#include "p1906-mol-perturbation.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-perturbation.h"
#include "p1906-mol-message-carrier.h"
#include "ns3/simulator.h"
#include "ns3/spectrum-value.h"
#include <bitset>
#include <unordered_map>


namespace ns3 {
#define MOST_LEFT_BIT_UINT8 (UINT8_MAX / 2 + 1)
NS_LOG_COMPONENT_DEFINE ("P1906MOLPerturbation");

TypeId P1906MOLPerturbation::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLPerturbation")
    .SetParent<P1906Perturbation> ();
  return tid;
}

P1906MOLPerturbation::P1906MOLPerturbation ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLPerturbation::~P1906MOLPerturbation ()
{
  NS_LOG_FUNCTION (this);
}

void
P1906MOLPerturbation::SetPulseInterval (Time t)
{
  NS_LOG_FUNCTION (this << t);
  m_pulseInterval = t;
}

Time
P1906MOLPerturbation::GetPulseInterval (void)
{
  NS_LOG_FUNCTION (this);
  return m_pulseInterval;
}

void
P1906MOLPerturbation::SetMolecules (double q)
{
  NS_LOG_FUNCTION (this << q);
  m_molecules = q;
}

double
P1906MOLPerturbation::GetMolecules (void)
{
  NS_LOG_FUNCTION (this);
  return m_molecules;
}


Ptr<P1906MessageCarrier>
P1906MOLPerturbation::CreateMessageCarrier (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);


  std::string tipodemol;
  std::string molmod = "";


  Ptr<P1906MOLMessageCarrier> carrier = CreateObject<P1906MOLMessageCarrier> ();

  double duration = m_pulseInterval.GetSeconds () * p->GetSize () * 8;
  double now = Simulator::Now ().GetSeconds ();


  //std::vector < std::vector<int> >  mod (int(p->GetSize()), std::vector<int>(8));
  



  NS_LOG_FUNCTION (this << "[t,bits,pulseI,duration]" << now << p->GetSize() * 8
		  << m_pulseInterval << duration);

  uint8_t *buffer = new uint8_t[p->GetSize ()];
  p->CopyData(buffer, p->GetSize ());
  //std::vector<std::string>  tmol;
   std::vector<std::string> aminoacidosa;
   std::vector<double> mod;
std::string codificadorAminoacido (uint8_t buffer);
std::string mapa_aminoacido(const std::string& codon);

    for (int i = 0; i < int(p->GetSize()); i++) {
      aminoacidosa.push_back(codificadorAminoacido(buffer[i]));
      mod.push_back(m_molecules);

    NS_LOG_FUNCTION("Packet" << i << ":" << codificadorAminoacido(buffer[i]));
    
  }



    /* Muestra el mensaje enviado
    for (int m = 0; m<int(p->GetSize()); m++){
      for (int c = 0; c<3;c++){
        		  molmod = molmod + std::to_string(mod[m][c]) + " | ";
        	  }
        	  NS_LOG_FUNCTION(" Molecules: " << molmod);
    }*/


  carrier->SetPulseInterval (m_pulseInterval);
  carrier->SetDuration (Seconds(duration));
  carrier->SetStartTime (Simulator::Now ());
  carrier->SetMolecules (GetMolecules ());
  carrier->SetMessage (p);


  carrier->SetAminoacido(aminoacidosa);
  carrier->SetModulation(mod);

  return carrier;
}

std::string mapa_aminoacido(const std::string& codon) {
    // Tabla de codones a aminoácidos
    std::unordered_map<std::string, std::string> codones_a_aminoacidos = {
        {"UUU", "Fenilalanina"},     {"UCU", "Serina"},           {"UAU", "Tirosina"},          {"UGU", "Cisteína"},
        {"UUC", "Fenilalanina"},     {"UCC", "Serina"},           {"UAC", "Tirosina"},          {"UGC", "Cisteína"},
        {"UUA", "Leucina"},          {"UCA", "Serina"},           {"UAA", "Codón de parada"},   {"UGA", "Codón de parada"},
        {"UUG", "Leucina"},          {"UCG", "Serina"},           {"UAG", "Codón de parada"},   {"UGG", "Triptófano"},
        {"CUU", "Leucina"},          {"CCU", "Prolina"},          {"CAU", "Histidina"},         {"CGU", "Arginina"},
        {"CUC", "Leucina"},          {"CCC", "Prolina"},          {"CAC", "Histidina"},         {"CGC", "Arginina"},
        {"CUA", "Leucina"},          {"CCA", "Prolina"},          {"CAA", "Glutamina"},         {"CGA", "Arginina"},
        {"CUG", "Leucina"},          {"CCG", "Prolina"},          {"CAG", "Glutamina"},         {"CGG", "Arginina"},
        {"AUU", "Isoleucina"},       {"ACU", "Treonina"},         {"AAU", "Asparagina"},        {"AGU", "Serina"},
        {"AUC", "Isoleucina"},       {"ACC", "Treonina"},         {"AAC", "Asparagina"},        {"AGC", "Serina"},
        {"AUA", "Isoleucina"},       {"ACA", "Treonina"},         {"AAA", "Lisina"},            {"AGA", "Arginina"},
        {"AUG", "Metionina (Inicio)"},{"ACG", "Treonina"},        {"AAG", "Lisina"},            {"AGG", "Arginina"},
        {"GUU", "Valina"},           {"GCU", "Alanina"},          {"GAU", "Ácido aspártico"},   {"GGU", "Glicina"},
        {"GUC", "Valina"},           {"GCC", "Alanina"},          {"GAC", "Ácido aspártico"},   {"GGC", "Glicina"},
        {"GUA", "Valina"},           {"GCA", "Alanina"},          {"GAA", "Ácido glutámico"},   {"GGA", "Glicina"},
        {"GUG", "Valina"},           {"GCG", "Alanina"},          {"GAG", "Ácido glutámico"},   {"GGG", "Glicina"},
    };

    // Convertir el codón a mayúsculas para asegurar la comparación
    std::string codon_upper = codon;
    for (char& c : codon_upper) {
        c = std::toupper(c);
    }

    // Obtener el aminoácido correspondiente al codón
    auto it = codones_a_aminoacidos.find(codon_upper);
    if (it != codones_a_aminoacidos.end()) {
        return it->second;
    } else {
        return "Desconocido";
    }
}
std::string uint8ToBinary(uint8_t value) {
    std::string binaryString;
    for (int i = 5; i >= 0; --i) {
        binaryString += ((value >> i) & 1) ? '1' : '0';
    }
    return binaryString;
}

// Función para aplicar la codificación a cada par de bits
std::string aplicarCodificacion(uint8_t value) {
    std::string binaryString = uint8ToBinary(value);
    std::string resultado;

    for (std::size_t i = 0; i < binaryString.size(); i += 2) {
        // Obtener cada par de bits
        std::string parDeBits = binaryString.substr(i, 2);

        // Aplicar la codificación
        if (parDeBits == "00") {
            resultado += 'U';
        } else if (parDeBits == "01") {
            resultado += 'C';
        } else if (parDeBits == "10") {
            resultado += 'A';
        } else if (parDeBits == "11") {
            resultado += 'G';
        }
    }
//std::cout << "Valor original en binario: " << uint8ToBinary(value) << std::endl;
    //std::cout << "Resultado codificado: " << resultado<< std::endl;
    return resultado;
}

std::string codificadorAminoacido (uint8_t buffer){
  /*int aux=0;
  std::string bitsTX="";
  std::vector<char>  tmol(3);
   for (int j = 0; j < 6; j += 2) {
        std::bitset<2> bits((buffer >> j) & 0b11);
        std::cout << bits << std::endl;
    if(bits==0b00){
      
      tmol[aux]='U';
      bitsTX = bitsTX + "U";

    }else if(bits==0b01){
      
      tmol[aux]='C';
      bitsTX = bitsTX + "C";

    } else if (bits==0b10){
      
      tmol[aux]='A';
      bitsTX = bitsTX + "A";
      
    }else if(bits==0b11){
      
      tmol[aux]='G';
      bitsTX = bitsTX + "G";
    }
    aux++;      
    }*/
    return mapa_aminoacido(aplicarCodificacion(buffer));
    

}




} // namespace ns3
