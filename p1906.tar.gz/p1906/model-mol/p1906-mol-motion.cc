/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright © 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE Std 1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE Std 1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 */

#include "ns3/log.h"

#include "p1906-mol-motion.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-field.h"
#include "ns3/mobility-model.h"
#include "ns3/p1906-net-device.h"
#include <ns3/spectrum-value.h>
#include "p1906-mol-message-carrier.h"
#include <chrono>
#include <random>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <string>
#include <algorithm>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("P1906MOLMotion");

TypeId P1906MOLMotion::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLMotion")
    .SetParent<P1906Motion> ();
  return tid;
}

P1906MOLMotion::P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLMotion::~P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this);
}


double
P1906MOLMotion::ComputePropagationDelay (Ptr<P1906CommunicationInterface> src,
		                                Ptr<P1906CommunicationInterface> dst,
		                                Ptr<P1906MessageCarrier> message,
		                                Ptr<P1906Field> field)
{

  /*
   * The Motion component implements a propagation model as presented in
   *
   * Detection Techniques for Diffusion-based Molecular Communication
   * I Llatser, A Cabellos-Aparicio, M Pierobon, E Alarcón
   * Selected Areas in Communications, IEEE Journal on 31 (12), 726-734
   *
   */

  NS_LOG_FUNCTION (this << "Fick's low");

  Ptr<MobilityModel> srcMobility = src->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
  Ptr<MobilityModel> dstMobility = dst->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();


  double distance = dstMobility->GetDistanceFrom (srcMobility);
  //2D
  double delay = pow(distance,2)/(GetDiffusionConefficient ()*4);
  //double delay = pow(distance,2)/(GetDiffusionConefficient ()*6);
  double diffusion = GetDiffusionConefficient ();

  NS_LOG_FUNCTION (this << "[dist,diffusion,delay]" << distance <<  diffusion << delay);
 
  return delay;
}


Ptr<P1906MessageCarrier>
P1906MOLMotion::CalculateReceivedMessageCarrier(Ptr<P1906CommunicationInterface> src,
		                                       Ptr<P1906CommunicationInterface> dst,
		                                       Ptr<P1906MessageCarrier> message,
                                           std::vector < std::vector<double> > RxTime,
		                                       Ptr<P1906Field> field)
{

  NS_LOG_FUNCTION (this << "Do nothing for the Fick's low");
  std::vector <double> time;
  /*for (size_t i = 0; i < RxTime.size(); i++) {
	std::cout<<"----------------------"<<std::endl;
        // Recorre las columnas de cada fila
        for (size_t j = 0; j < RxTime[i].size(); j++) {
            // Imprime cada elemento de la matriz
            std::cout << RxTime[i][j] << " ";
        }
        // Salto de línea al final de cada fila
        std::cout << std::endl;
    }*/

    /*
for (int i=0; i<int(RxTime.size()); i++){ //Matriz con todos los tiempos de cada bit
	  time.resize(0);
	  for (int j=0; j<int(RxTime[i].size()); j++){ //Sacamos fila por fila los tiempos
		  if (RxTime[i][j] !=0){
			  time.push_back(RxTime[i][j]);
		  }
	  }
	  sort(time.begin(),time.end()); //Ordenamos el vector tiempo
}*/



  return message;
}


void
P1906MOLMotion::SetDiffusionCoefficient (double d)
{
  NS_LOG_FUNCTION (this << d);
  m_diffusionCoefficient = d;
}

double
P1906MOLMotion::GetDiffusionConefficient (void)
{
  NS_LOG_FUNCTION (this);
  return m_diffusionCoefficient;
}






std::vector<std::vector<double>>
  P1906MOLMotion::BrownianMotion(std::vector<std::vector<double>> vectorXY, char tipomolec)
  {
    double xi = 0;
    double yi = 0;
    double m_theta = 0.;
    /*double m_theta1 = 0.; // Angulo reflexion
    double ha = 0;
    double L = 0;
    double mod = 0;
    double mod1 = 0;
    double x1 = 0;
    double y1 = 0;*/
    

    std::string xy = "";
    std::vector<double> x;
    std::vector<double> y;

  
    double raiz = sqrt(4 * m_diffusionCoefficient * m_deltat);
    
  
    for (int i = 0; i < m_nOfMol; i++)
    {

      m_theta = ComputeRVGauss(0.0, 2 * M_PI);

      if (vectorXY[i][0] == 1)
      {
        xi = vectorXY[i][2];
        yi = vectorXY[i][3];
      }
      else
      {
       
        xi = vectorXY[i][2] + raiz * cos(m_theta); // Crear una variable para la raiz y sacar del for
        yi = vectorXY[i][3] + raiz * sin(m_theta);
        /*if (yi > m_uplimitvein || yi < m_lowlimitvein)
        {
          // m_theta1 = atan(((tan(m_theta)-u)/e)-u);//revisar OJO
          m_theta1 = m_theta;
          ha = abs(m_uplimitvein - abs(vectorXY[i][3]));
          mod = ha / abs(sin(m_theta));
          L = mod * abs(cos(m_theta));
          mod1 = abs(raiz - mod);
          if (vectorXY[i][2] < xi)
          { // Rebota ADELANTE
            if (yi > m_uplimitvein)
            { // Limite Superior
              x1 = vectorXY[i][2] + L;
              y1 = vectorXY[i][3] + ha;
              xi = x1 + mod1 * abs(cos(m_theta1)); // X2
              yi = y1 - mod1 * abs(sin(m_theta1)); // Y2
            }
            else
            { // Limite Inferior
              x1 = vectorXY[i][2] + L;
              y1 = vectorXY[i][3] - ha;
              xi = x1 + mod1 * abs(cos(m_theta1)); // X2
              yi = y1 + mod1 * abs(sin(m_theta1)); // Y2
            }
          }
          else
          { // Rebota ATRAS
            if (yi > m_uplimitvein)
            { // Limite Superior
              x1 = vectorXY[i][2] - L;
              y1 = vectorXY[i][3] + ha;
              xi = x1 + mod1 * abs(cos(m_theta1)); // X2
              yi = y1 - mod1 * abs(sin(m_theta1)); // Y2
            }
            else
            { // Limite Inferior
              x1 = vectorXY[i][2] - L;
              y1 = vectorXY[i][3] - ha;
              xi = x1 - mod1 * abs(cos(m_theta1)); // X2
              yi = y1 + mod1 * abs(sin(m_theta1)); // Y2
            }
          }
        }*/
        //std::cout<<"xggg"<<i<<" "<<xi<<" "<<yi<<std::endl;
      }
      vectorXY[i][2] = xi;
      vectorXY[i][3] = yi;

    }
    return vectorXY;
  }

std::vector <std::vector<double> >
P1906MOLMotion::BrownianMotionDrift (std::vector <std::vector<double> > vectorXY, std::string Aminoacido, Ptr<P1906Field> field)
{

  double xi = 0;
  double yi = 0;
  double m_theta = 0.;
  
  /*double e = 1; 							//Coeficiente de restitucion
  double u = 1;								//Coeficiente de friccion
  double m_theta1 = 0.;						//Angulo reflexion
  double ha = 0;
  double L = 0;
  double mod = 0;
  double mod1 = 0;
  double x1 = 0;
  double y1 = 0;*/
  double vel = field->GetVelocityDrift();
  double anguledrift = field->GetAngleDrift();
  /*std::cout<<"Velocidad ---->"<<vel<<std::endl;
  std::cout<<"Angulo ---->"<<anguledrift<<std::endl;*/

  double raiz = sqrt(4 * m_diffusionCoefficient * m_deltat);
  double vxt= (vel * cos(anguledrift) * m_deltat);
  double vyt = (vel * sin(anguledrift) * m_deltat);

  //std::cout<<"Vel x "<<vxt<<"Vel y "<<vyt<<std::endl;

  std::string xy = "";
  std::vector <double> x;
  std::vector <double> y;

  for (int i = 0; i < m_nOfMol; i++){
	  m_theta = ComputeRVGauss(0.0,2*M_PI);
	  if (vectorXY[i][0] == 1){
		  xi = vectorXY[i][2];
		  yi = vectorXY[i][3];
	  } else {
		  xi = vectorXY[i][2] + (raiz * cos(m_theta)) + vxt;
		  yi = vectorXY[i][3] + (raiz * sin(m_theta)) + vyt;
      //xi = vectorXY[i][2] + raiz * cos(m_theta);
		  //yi = vectorXY[i][3] + raiz * sin(m_theta);
		  /*if (yi > m_uplimitvein || yi < m_lowlimitvein){
			  m_theta1 = atan(((tan(m_theta)-u)/e)-u);// Condition for rebound angle
			  m_theta1 = m_theta;
			  ha = abs(m_uplimitvein - abs(vectorXY[i][3]));
			  mod = ha/abs(sin(m_theta));
			  L = mod*abs(cos(m_theta));
			  mod1 = abs(raiz - mod);
			  if (vectorXY[i][2] < xi){ //Rebota ADELANTE
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  } else { //Rebota ATRAS
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 - mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  }
		  }*/
	  }
	vectorXY [i][2] = xi;
	vectorXY [i][3] = yi;
  }
  return vectorXY;

}

  double
  P1906MOLMotion::ComputeRVGauss(double media, double var)
  {
    double RV;
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine generator(seed);
    std::normal_distribution<double> distribution(media, var);

    // for (int i=0; i<10; ++i)
    RV = distribution(generator);
    return RV;
  }









  double
  P1906MOLMotion::GetnOfMol(void)
  {
    NS_LOG_FUNCTION(this);
    return m_nOfMol;
  }

  void
  P1906MOLMotion::SetnOfMol(double nOfMol)
  {
    NS_LOG_FUNCTION(this << nOfMol);
    m_nOfMol = nOfMol;
  }

  


  double
  P1906MOLMotion::GetDeltat(void)
  {
    NS_LOG_FUNCTION(this);
    return m_deltat;
  }

  void
  P1906MOLMotion::SetDeltat(double deltat)
  {
    NS_LOG_FUNCTION(this << deltat);
    m_deltat = deltat;
  }

  


} // namespace ns3
