/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 */

#include "ns3/log.h"

#include "p1906-mol-receiver-communication-interface.h"
#include "ns3/p1906-net-device.h"
#include <ns3/packet.h>
#include "ns3/p1906-specificity.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-medium.h"
#include "ns3/p1906-net-device.h"
#include "ns3/p1906-motion.h"
#include "p1906-mol-specificity.h"
#include <unordered_map>

namespace ns3
{

  NS_LOG_COMPONENT_DEFINE("P1906MOLReceiverCommunicationInterface");

  TypeId P1906MOLReceiverCommunicationInterface::GetTypeId(void)
  {
    static TypeId tid = TypeId("ns3::P1906MOLReceiverCommunicationInterface")
                            .SetParent<P1906ReceiverCommunicationInterface>();
    return tid;
  }

  P1906MOLReceiverCommunicationInterface::P1906MOLReceiverCommunicationInterface()
  {
    NS_LOG_FUNCTION(this);
  }

  P1906MOLReceiverCommunicationInterface::~P1906MOLReceiverCommunicationInterface()
  {
    NS_LOG_FUNCTION(this);
  }

  void
  P1906MOLReceiverCommunicationInterface::HandleReception(Ptr<P1906CommunicationInterface> src, Ptr<P1906CommunicationInterface> dst, Ptr<P1906MessageCarrier> message, double umbral)
  {
    NS_LOG_FUNCTION(this);
    bool isRxOk;
    std::string strTipoMol = "";
    //std::string strMoleRx = "";
    std::string strBitsRX = "";
    std::string decodificador_aminoacido(const std::string& codon);

    

    Ptr<P1906MOLSpecificity> specificity = GetP1906Specificity()->GetObject<P1906MOLSpecificity>();
    for (int nbit = 0; nbit < int(message->GetMessage()->GetSize()); nbit++)
    {
      isRxOk = specificity->CheckRxCompatibility(src, dst, message, nbit);

      std::vector<std::string> aminoacido;
      aminoacido = message->GetAminoacido();

      if (isRxOk)
      {
        NS_LOG_FUNCTION(this << "message received correctly");
        Ptr<Packet> p = message->GetMessage();
        // xxx forward to upper layer
        

        std::vector <double> bitsrx;
        
        //strTipoMol = strTipoMol + tipomol[nbit];
        //strMoleRx = strMoleRx + std::to_string(bitsrx[0][nbit]);

        bitsrx = message->GetModulation();
        

        double bitmodulado=bitsrx[nbit];
        std::cout<<"Numero de moleculas moduladas "<<bitmodulado<<std::endl;
          std::cout<<"Tipo de aminoacido "<<aminoacido [nbit]<<std::endl;
          //std::cout<<"Modulacion "<<bitsrx[0][nbit]<<std::endl;
          //std::cout<<"Umbral "<<umbral<<std::endl;
          std::vector<std::vector<double>> multiplicarMatrices(std::vector<std::vector<double>> a, std::vector<std::vector<double>> b);
  std::vector<std::vector<double>> potenciaMatriz(std::vector<std::vector<double>> matriz, int n);
  std::vector<std::vector<double>> matrizTransicion = {{0.4, 0.7},
                                                         {0.6, 0.3}};
    
    // Vector de estados iniciales
    std::vector<std::vector<double>> estadosIniciales = {{0},
                                                         {bitmodulado}};
    
    // Definir el número máximo de tiempo (k)
    int k = 1; // Cambiar este valor para calcular hasta el tiempo k
    std::vector<std::vector<double>> resultado;
    for (int i = 1; i <= k; ++i) {
        // Calcular la matriz de transición elevada a la potencia i
        std::vector<std::vector<double>> matrizPotencia = potenciaMatriz(matrizTransicion, i);
        
        // Multiplicar la matriz de transición^i por el vector de estados iniciales
        resultado = multiplicarMatrices(matrizPotencia, estadosIniciales);
        
        // Imprimir el resultado para el tiempo i
        std::cout << "Moleculas ligadas " << ": " << resultado[0][0] << ", Moleculas libres: " << resultado[1][0] << std::endl;
    }

         /*if (resultado[0][0] >= umbral)
          {
            if (tipomol[nbit] == 'U')
            {
              strBitsRX = strBitsRX + "00";
            }
            else if (tipomol[nbit] == 'C')
            {
              strBitsRX = strBitsRX + "01";
            }
            else if (tipomol[nbit] == 'A')
            {
              strBitsRX = strBitsRX + "10";
            }
            else if (tipomol[nbit] == 'G')
            {
              strBitsRX = strBitsRX + "11";
            }
          }
          else
          {
            strBitsRX = strBitsRX + "XX";
          }*/        
      }
      else
      {
        NS_LOG_FUNCTION(this << "message NOT received correctly");
        // ignore the message carrier
      }
    }
    //NS_LOG_FUNCTION("Packet: " << strTipoMol );
    //NS_LOG_FUNCTION("Molecules: " << strMoleRx );
    //NS_LOG_FUNCTION("Packet received: " << strBitsRX );

    /*for (int i = 0; i < 3; i++) {
        strTipoMol += (tipomol[i] );
    }
    std::cout<<"El codon es: "<<strTipoMol<<std::endl;
    std::cout<<"El aminoacido es: "<<decodificador_aminoacido(strTipoMol)<<std::endl;*/
  }
  
std::vector<std::vector<double>> multiplicarMatrices(std::vector<std::vector<double>> a, std::vector<std::vector<double>> b) {
std::vector<std::vector<double>> resultado(2, std::vector<double>(2, 0.0));

    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            for (int k = 0; k < 2; ++k) {
                resultado[i][j] += a[i][k] * b[k][j];
            }
        }
    }

    return resultado;
}

// Función para elevar una matriz 2x2 a una potencia n
std::vector<std::vector<double>> potenciaMatriz(std::vector<std::vector<double>> matriz, int n) {
    if (n == 1) {
        return matriz;
    } else {
        std::vector<std::vector<double>> resultado = potenciaMatriz(matriz, n / 2);
        resultado = multiplicarMatrices(resultado, resultado);
        if (n % 2 == 1) {
            resultado = multiplicarMatrices(resultado, matriz);
        }
        return resultado;
    }
}


  


  /*std::string decodificador_aminoacido(const std::string& codon) {
    // Tabla de codones a aminoácidos
    std::unordered_map<std::string, std::string> codones_a_aminoacidos = {
        {"UUU", "Fenilalanina"},     {"UCU", "Serina"},           {"UAU", "Tirosina"},          {"UGU", "Cisteína"},
        {"UUC", "Fenilalanina"},     {"UCC", "Serina"},           {"UAC", "Tirosina"},          {"UGC", "Cisteína"},
        {"UUA", "Leucina"},          {"UCA", "Serina"},           {"UAA", "Codón de parada"},   {"UGA", "Codón de parada"},
        {"UUG", "Leucina"},          {"UCG", "Serina"},           {"UAG", "Codón de parada"},   {"UGG", "Triptófano"},
        {"CUU", "Leucina"},          {"CCU", "Prolina"},          {"CAU", "Histidina"},         {"CGU", "Arginina"},
        {"CUC", "Leucina"},          {"CCC", "Prolina"},          {"CAC", "Histidina"},         {"CGC", "Arginina"},
        {"CUA", "Leucina"},          {"CCA", "Prolina"},          {"CAA", "Glutamina"},         {"CGA", "Arginina"},
        {"CUG", "Leucina"},          {"CCG", "Prolina"},          {"CAG", "Glutamina"},         {"CGG", "Arginina"},
        {"AUU", "Isoleucina"},       {"ACU", "Treonina"},         {"AAU", "Asparagina"},        {"AGU", "Serina"},
        {"AUC", "Isoleucina"},       {"ACC", "Treonina"},         {"AAC", "Asparagina"},        {"AGC", "Serina"},
        {"AUA", "Isoleucina"},       {"ACA", "Treonina"},         {"AAA", "Lisina"},            {"AGA", "Arginina"},
        {"AUG", "Metionina (Inicio)"},{"ACG", "Treonina"},        {"AAG", "Lisina"},            {"AGG", "Arginina"},
        {"GUU", "Valina"},           {"GCU", "Alanina"},          {"GAU", "Ácido aspártico"},   {"GGU", "Glicina"},
        {"GUC", "Valina"},           {"GCC", "Alanina"},          {"GAC", "Ácido aspártico"},   {"GGC", "Glicina"},
        {"GUA", "Valina"},           {"GCA", "Alanina"},          {"GAA", "Ácido glutámico"},   {"GGA", "Glicina"},
        {"GUG", "Valina"},           {"GCG", "Alanina"},          {"GAG", "Ácido glutámico"},   {"GGG", "Glicina"},
    };

    // Convertir el codón a mayúsculas para asegurar la comparación
    std::string codon_upper = codon;
    for (char& c : codon_upper) {
        c = std::toupper(c);
    }

    // Obtener el aminoácido correspondiente al codón
    auto it = codones_a_aminoacidos.find(codon_upper);
    if (it != codones_a_aminoacidos.end()) {
        return it->second;
    } else {
        return "Desconocido";
    }
}*/

} // namespace ns3
